<?php
use App\Http\Controllers\CategoryController;

use App\Http\Controllers\AdminStatController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController; // for the user creating 
use App\Http\Controllers\UserTypeController;
use App\Http\Controllers\CollectorMarketInfoController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\OrderJourneyController;
use App\Http\Controllers\DeliveryAppController;
use App\Http\Controllers\DeliveryController;
use App\http\Middleware\CheckUpdateAuth;
use App\http\Middleware\CheckMarket;
use App\http\Middleware\CheckUniqueCardNumber;
use App\Http\Controllers\CardInfoController;
use App\Http\Controllers\WalletController;
use App\Http\Controllers\BasketOrderController;
use App\Http\Controllers\NotificationController;
use App\Http\Middleware\CollectorCheckUpdate;
use App\Http\Middleware\CollectorStatus;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// USERS - all of them - 
//--------------------------------------------------------------------------
//User

// For the user to register - creating an account-
Route::post('register',[UserController::class,'create']); 

// For the login - any user can log in -
Route::post('login',[UserController::class,'login']);

// This step comes after the register and login - check the otp, and create token for the user -
Route::post('verifyOtp',[UserController::class,'verifyOtp']);

// For the logout
Route::post('logout',[UserController::class,'logout'])  ->middleware('auth:sanctum');

// For reset password 
Route::post('resetPassword',[UserController::class,'resetPassword']);

// to update the password after the reset
Route::post('resetPassword.updatePassword',[UserController::class,'updatePassword'])
->middleware('auth:sanctum');

//Updating the account_status
Route::put('update/{id}', [UserController::class, 'update'])
->middleware('auth:sanctum');

//to update user state - only the admin- 
Route::post('updateUserStatus/{id}', [UserController::class, 'updateUserStatus'])
->middleware('auth:sanctum')->middleware(CheckUpdateAuth::class);

// Notification for the admin when a collector  or market added
//Route::post('/notifications', [NotificationController::class, 'create']);


// To update the market account . . . .
// Get the information 
Route::get('/market/account', [UserController::class, 'viewMarketAccount'])
->middleware(['auth:sanctum', 'collectorStatus']);


// // update the information 
Route::post('/market/update', [UserController::class, 'updateMarket'])
->middleware(['auth:sanctum', 'collectorStatus']);


// View the aacount status of the collector for the admin 
Route::get('view/CollectorsStatus',[UserController::class,'viewCollectorsStatus'])
->middleware(['auth:sanctum', 'collectorStatus']);


// View the aacount status of the market for the admin 
Route::get('view/MarketsStatus',[UserController::class,'viewMarketsStatus'])
->middleware(['auth:sanctum', 'checkMarket']);

// Filter for the markets - search for specific market - 
Route::post('filter.markets',[UserController::class,'marketFilter']);


// Filter for product of specific market 
Route::post('filter.products/{market_id}',[ProductController::class,'productFilter']);


// Filter category of specific market 
Route::post('filter.category/{market_id}',[CategoryController::class,'categoryFilter']);

// delete_update_reset

// Return the status of specific collector - active or inactive-
Route::get('getCollectorStatus/{id}',[UserController::class, 'getCollectorStatus'])
->middleware('auth:sanctum')->middleware(CollectorCheckUpdate::class);

// !!!Collector Updating the Status of his account -> (active / inactive)
Route::post('updateCollectorStatus',[UserController::class,'collectorUpdate'])
->middleware('auth:sanctum')->middleware(CollectorCheckUpdate::class);


// The customer can view the markets 
Route::post('viewMarkets',[UserController::class,'viewMarkets']);
//------------------------------------------------------------------
//UserType

// For adding the types by the super admin  
Route::post('User_Types',[UserTypeController::class,'create_user_type'])
->middleware('auth:sanctum')->middleware(CheckUpdateAuth::class); 


// delete_update_reset
// Collector Updating the Status of his account -> (active / inactive)
Route::post('collectorUpdate',[UserController::class,'collectorUpdate'])
->middleware('auth:sanctum')->middleware(CollectorCheckUpdate::class);



//To view the types with their information 
Route::get('type',[UserTypeController::class,'type']);


//-----------------------------------------------------------------------
// CollectorMarketInfo

// For creating the collector__market__infos
Route::post('info',[CollectorMarketInfoController::class,'fill_info']);

//-----------------------------------------------------------------------------
//ORDER

// Add the customer order in the Order table
Route::post('addOrder',[OrderController::class,'addOrder'])
->middleware('auth:sanctum');


// To view the Orders to the collecotrs, only when the status is 'active'
Route::get('viewOrders',[OrderController::class,'viewOrders'])
//->middleware('auth:sanctum');
//->middleware(CollectorStatus::class);
//->middleware('collectorStatus');
->middleware(['auth:sanctum',CollectorStatus::class]);
//->middleware(['auth:sanctum', 'collectorStatus']);



// Collctor can view specific information of specific order 
Route::get('viewOrder/{order_id}',[BasketOrderController::class,'viewOrder'])
//->middleware('auth:sanctum');
//'auth:sanctum',
//CollectorStatus::class
->middleware(['auth:sanctum', 'collectorStatus']);
//Route::get('login', ['middleware' => ['qwickAuth'], 'uses' =>'WebController@login']);



// The collector can except specific order  
Route::post('acceptOrder',[OrderJourneyController::class,'acceptOrder'])
->middleware(['auth:sanctum',CollectorStatus::class]);


//  To update the status of the order (collected)
Route::post('updateOrderStatus',[OrderJourneyController::class,'updateOrderStatus'])
->middleware(['auth:sanctum',CollectorStatus::class]);
//->middleware(['auth:sanctum', 'collectorStatus']);


// To view the dashboard of a specific market 
Route::get('market/dashboard',[UserController::class,'viewDashMarket'])
->middleware('auth:sanctum')->middleware(CheckMarket::class);
//->middleware(['auth:sanctum', 'collectorStatus']);



// To view the dashboard of a specific market 
Route::get('market/dashboard',[UserController::class,'viewDash'])
->middleware(['auth:sanctum', 'checkMarket']);


// To view the dash board for the admin 
Route::get('admin/dashboard',[UserController::class,'viewDashAdmin'])
->middleware('auth:sanctum')->middleware(CheckUpdateAuth::class);


//------------------------------------------------------------------------------------------
//DELIVERY / DELIVERY_APP

// To create a token for the delivery app - only once- 
Route::post('createToken',[DeliveryAppController::class,'createToken']);

// To add a delivery app 
Route::post('addDeliveryApp',[DeliveryAppController::class,'addDeliveryApp']);

// delete_update_reset
// The customer can view the markets 
Route::get('viewMarkets',[UserController::class,'viewMarkets']);


Route::post('updateDelivery',[DeliveryController::class,'updateDelivery']);

// delete_update_reset
// To add a delivery app - only be the admin - 
Route::post('addDeliveryApp',[DeliveryAppController::class,'addDeliveryApp'])
->middleware('auth:sanctum')->middleware('checkUpdateAuth');
//--------------------------------------------------------------------------------------------


///// Admin stats -- AdminController\\\\
// get the total number of users
Route::get('getNumberOfUsers', [AdminStatController::class, 'getNumberOfUsers']);


//get the total Number Of Collectors
Route::get('getNumberOfCollectors', [AdminStatController::class, 'getNumberOfCollectors']);


//get the total Number Of Markets
Route::get('getNumberOfMarkets', [AdminStatController::class, 'getNumberOfMarkets']);

//--------------------------------------------------------------------------------------------------

//get the total number of orders
Route::get('getNumberOfOrders', [AdminStatController::class, 'getNumberOfOrders']);

//get the total number of finished orders
Route::get('getNumberOfFinishedOrders', [AdminStatController::class, 'getNumberOfFinishedOrders']);

//get the total profit
Route::get('getAppProfit', [AdminStatController::class, 'getAppProfit']);

//get the total profit for the collector
Route::get('getCollectorProfit', [AdminStatController::class, 'getCollectorProfit']);

//-----------------------------------------------------------------------------------------------
//return all the info for all the users
Route::get('showAllUsersDetailedInfo', [AdminStatController::class, 'showAllUsersDetailedInfo']);

//return email - phone - name of the users
Route::get('showBasicUsersInfo', [AdminStatController::class, 'showBasicUsersInfo']);

//show a Specific User Info
Route::get('showSpecificUserInfo/{id}', [AdminStatController::class, 'showSpecificUserInfo']);

//--------------------------------------------------------------------------------------
//GET COLLECTORT INFO
//return all the info for all the collectors
Route::get('showAllCollectorsDetailedInfo', [AdminStatController::class, 'showAllCollectorsDetailedInfo']);

//return email - phone - name of the collectors
Route::get('showBasicCollectorsInfo', [AdminStatController::class, 'showBasicCollectorsInfo']);

//show a Specific collector Info
Route::get('showSpecificCollectorInfo/{id}', [AdminStatController::class, 'showSpecificCollectorInfo']);

//showCollectorsRegistrationRequests
Route::get('showCollectorsRegistrationRequests',[AdminStatController::class,'showCollectorsRegistrationRequests']);

//-----------------------------------------------------------------------------------------------
//GET MARKET INFO

//return all the info for all the markets
Route::get('showAllMarketsDetailedInfo', [AdminStatController::class, 'showAllMarketsDetailedInfo']);

//return email - phone - name of the markets
Route::get('showBasicMarketsInfo', [AdminStatController::class, 'showBasicMarketsInfo']);

//show a Specific markets Info
Route::get('showSpecificMarketInfo/{id}', [AdminStatController::class, 'showSpecificMarketInfo']);

//----------------------------------------------------------------------------------------------

// Delete a record from the user table 
Route::post('delete',[AdminStatController::class,'delete']);

//showTransactionsInfo
Route::post('showTransactionsInfo',[AdminStatController::class,'showTransactionsInfo']);
//---------------------------------------------------------------------
//END OF AdminController
//

//-------------------------------------------------------------------
// CategoryController
Route::prefix('categories/')->middleware(['auth:sanctum'])->group(function () {

    Route::get('index', [CategoryController::class, 'index']);
    Route::post('create', [CategoryController::class, 'create']);
    Route::get('show/{id}', [CategoryController::class, 'show']);
    Route::put('update/{id}', [CategoryController::class, 'update']);
    Route::delete('delete/{id}', [CategoryController::class, 'destroy']);
});
//-------------------------------------------------------------------------

//-------------------------------------------------------------------
//Proudct

// Customer view market product (when market choosen from main page)
//Route::get('viewProducts/{id}',[ProductController::class,'viewProducts']);

// Market Adding products
// Route::post('addProducts',[ProductController::class,'addProducts'])
// ->middleware('auth:sanctum')->middleware(CheckMarket::class); // middleware to check if the user market or not 

// // Market delete specific product 
// //Route::post('deleteProduct',[ProductController::class,'deleteProduct']);
// Route::delete('deleteProduct',[ProductController::class,'deleteProduct']) // 
// ->middleware('auth:sanctum')->middleware(CheckMarket::class);



//route::apiResource('posts',PostController:class);
//             follow the naming conventions for the 5 basic functions
// make the server do something for me, ordered get automatically cancled
/**
 * making a  command, putting my logic inside this command, and then this command is ran based on a time i deiced
 * 
 */

//------------------------------------------------------------------------------
//Product

// delete_update_reset
// Route::middleware(['auth:sanctum'])->group(function () {
// Route::get('products.viewProducts/{market_id}', [ProductController::class, 'viewProducts']);
// Route::post('products.addProduct', [ProductController::class, 'addProducts']);
// Route::get('products.show/{market_id}/{product_id}', [ProductController::class, 'showProduct']);
// Route::put('products.updateProduct/{id}', [ProductController::class, 'updateProduct']);
// Route::delete('products.deleteProduct/{id}', [ProductController::class, 'deleteProduct']); // market will delete its product 
// });
 

Route::prefix('products/')->middleware(['auth:sanctum'])->group(function () {
   
    Route::get('view/{market_id}', [ProductController::class, 'index']);
    Route::post('add', [ProductController::class, 'store']);
    Route::get('show/{market_id}/{product_id}', [ProductController::class, 'show']); //delete market id
    Route::put('update/{id}', [ProductController::class, 'update']);
    Route::delete('delete/{id}', [ProductController::class, 'destroy']); 
}); //add auth on the delete method to check that the market id from the auth
 
//------------------------------------------------------------------------------
//CardInfo

 Route::prefix('card_infos/')->middleware(['auth:sanctum'])->group(function () {

    Route::get('index', [CardInfoController::class, 'index']);
    Route::post('create', [CardInfoController::class, 'create']);//->middleware(CheckUniqueCardNumber::class);
    Route::get('show/{card_id}', [CardInfoController::class, 'show']);
    Route::put('update/{card_id}', [CardInfoController::class, 'update']);
    Route::delete('delete/{card_id}', [CardInfoController::class, 'delete']);
});
//-----------------------------------------------------------------------------
//Wallet

//-----------------------------------------------------------------------------

Route::prefix('wallet/')->middleware(['auth:sanctum'])->group(function () {

    Route::get('index', [WalletController::class, 'index']);
  //  Route::post('create', [WalletController::class, 'store']);
    Route::get('show/{id}', [WalletController::class, 'show']);
    Route::get('showByUserID/{user_id}', [WalletController::class, 'showByUserID']);
    Route::put('update/{id}', [WalletController::class, 'update']);
    //Route::delete('delete/{id}', [WalletController::class, 'destroy']);
});
//-----------------------------------------------------------------------------
