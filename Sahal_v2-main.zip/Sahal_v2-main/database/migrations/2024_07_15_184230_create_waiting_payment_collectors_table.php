<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\QueryException;


return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
public function up()
    {
        Schema::create('waiting_payment_collectors', function (Blueprint $table) {
            $table->id('waiting_bill_id');
            $table->unsignedBigInteger('order_journey_id')->nullable();
            $table->foreign('order_journey_id')->references('id')->on('order_journeys')->onDelete('cascade');
            $table->string('invoice_picture');
            $table->date('date');
            $table->string('payment_status');
           
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //Schema::dropIfExists('waiting_payment_collectors');
    }
};

/**Schema::create('waiting_payment_collectors', function (Blueprint $table) {
            $table->id('waiting_bill_id');

            $table->unsignedBigInteger('user_id');
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');

            $table->unsignedBigInteger('collector_id');
            $table->foreign('collector_id')->references('id')->on('users')->onDelete('cascade');

            $table->double('total_price');
            $table->double('delivery_price');
            $table->unsignedBigInteger('market_id');
            $table->foreign('market_id')->references('id')->on('users')->onDelete('cascade');

            $table->string('invoice_picture');
            $table->date('date');
            $table->string('payment_status');
            $table->unsignedBigInteger('order_journey_id');
            $table->foreign('order_journey_id')->references('id')->on('order_journeys')->onDelete('cascade');
            $table->timestamps();
        }); */