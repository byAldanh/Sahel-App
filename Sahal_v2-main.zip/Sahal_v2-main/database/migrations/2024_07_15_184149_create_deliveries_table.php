<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\QueryException;

return new class extends Migration
{
    
    public function up()
    {
        Schema::create('deliveries', function (Blueprint $table) {
            $table->id('delivery_id');
            $table->string('delivery_name');
            $table->string('delivery_phone', 10);
            $table->unsignedBigInteger('order_id')->nullable();
            $table->foreign('order_id')->references('id')->on('order_journeys')->onDelete('cascade');
            $table->unsignedBigInteger('delivery_app_id')->nullable();
            $table->foreign('delivery_app_id')->references('id')->on('delivery_apps')->onDelete('cascade');
            $table->string('Delivery_status');
            $table->timestamps();
        });
    }

  
    public function down()
    {
        //Schema::dropIfExists('deliveries');
    }
};
