<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\QueryException;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('delivery_apps', function (Blueprint $table) {
            $table->id();
            $table->string('app_name');
            $table->string('app_token');
            $table->unsignedBigInteger('card_info_id')->nullable();
            $table->foreign('card_info_id')->references('id')->on('card_infos')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //Schema::dropIfExists('delivery_apps');
    }
};
