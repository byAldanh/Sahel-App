<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\QueryException;


return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('location_polygons', function (Blueprint $table) {
            $table->id('place_id');
            $table->string('place_name');
            $table->integer('postal_code');
            $table->double('x_coordinate');
            $table->double('y_coordinate');
            $table->geometry('geometry');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //Schema::dropIfExists('location__polygons');
    }
};
