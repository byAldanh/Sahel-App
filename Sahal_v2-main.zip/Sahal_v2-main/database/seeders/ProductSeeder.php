<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        DB::table('products')->insert([
            [
                'product_name' => 'Sample Product 1',
                'product_image' => 'sample_image_1.jpg',
                'price' => 120.50,
                'quantity' => 50,
                'barcode_image' => 'sample_barcode_1.jpg',
                'category_id' => 1, // assuming category with id 1 exists
                'market_id' => 1,   // assuming user with id 1 exists
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'product_name' => 'Sample Product 2',
                'product_image' => 'sample_image_2.jpg',
                'price' => 220.75,
                'quantity' => 30,
                'barcode_image' => 'sample_barcode_2.jpg',
                'category_id' => 2, // assuming category with id 2 exists
                'market_id' => 2,   // assuming user with id 2 exists
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);

    }
}
