<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('categories')->insert([
            
            [
                'category_name' => 'خضار وفواكة',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'category_name' => 'لحوم',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'category_name' => 'اجبان ومشتقاته',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'category_name' => 'المخبوزات',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'category_name' => 'البقول المجففة والأرز والمعكرونة',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'category_name' => 'الاطعمة المعلبة',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'category_name' => 'المحمصة',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'category_name' => 'الحلويات والسناكات',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'category_name' => 'منظفات وبلاستيكيات',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }
}
