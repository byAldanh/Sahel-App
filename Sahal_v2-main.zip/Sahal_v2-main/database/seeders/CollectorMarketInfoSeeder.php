<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CollectorMarketInfoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('collector_market_infos')->insert([
            
            [
                'info' => 'age',
                'user_type_id' => '2'
            ],
            [
                'info' => 'branch',
                'user_type_id' => '3'
            ],
            [
                'info' => 'commercial_register',
                'user_type_id' => '3'
            ],
            [
                'info' => 'logo',
                'user_type_id' => '3'
            ],
            [
                'info' => 'collector_status',
                'user_type_id' => '2'
            ]
        ]);
    }
}
