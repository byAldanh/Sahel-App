<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class OrderSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('orders')->insert([
            [
                'name_user' => 'John Doe',
                'phone_user' => '1234567890',
                'email_user' => 'john@examples.com',
                'password_user' => Hash::make('password'),
                'account_status' => 'active',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name_user' => 'Jane Doe',
                'phone_user' => '0987654321',
                'email_user' => 'jane@examples.com',
                'password_user' => Hash::make('password'),
                'account_status' => 'active',
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    
    }
}
