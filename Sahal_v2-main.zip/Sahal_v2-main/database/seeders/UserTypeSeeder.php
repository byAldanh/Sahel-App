<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UserTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('user_types')->insert([
            [
            'user_type' => 'Customer'
            ],

            [
                'user_type' => 'Collector'
            ],

            [
                'user_type' => 'Market'
            ],

            [
                'user_type' => 'Admin'
            ],
        ]);
    }
}
