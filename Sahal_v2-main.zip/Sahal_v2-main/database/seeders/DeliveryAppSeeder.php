<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DeliveryAppSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('delivery_apps')->insert([
            [
                'app_name' => 'khiffa',
                'app_token' => '6|kKxtra7tRxU46Tf9KRIyP7bl5y8azTL0kEAf3krn46ca4c62',
                'created_at' => now(),
                'updated_at' => now(),
            ]
        ]);
        }
}
