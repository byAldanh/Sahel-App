<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;

class CardInfoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();

        // Number of records to seed
        $numberOfRecords = 10;

        for ($i = 0; $i < $numberOfRecords; $i++) {
            DB::table('card_infos')->insert([
                'bank_name' => $faker->company,
                'iban' => $faker->iban('SA'),
                'card_number' => $faker->unique()->creditCardNumber, // Ensure uniqueness
                'name_on_card' => $faker->name,
                'expiry_date' => $faker->dateTimeBetween('now', '+2 years')->format('Y-m-d'),
                'type_of_card' => $faker->creditCardType,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
