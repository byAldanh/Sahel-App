<!DOCTYPE html>
<html>
    <head>
        <h1>OTP</h1>
    </head>
  
<h1>Your OTP: {{$user->otp_generated}}</h1>
</html>