<!DOCTYPE html>
<html>
    <head>
        <h1>Account Status Updated</h1>
    </head>
  
<h1>Your Account Status Updated to :{{$user->account_status}}</h1>
</html>