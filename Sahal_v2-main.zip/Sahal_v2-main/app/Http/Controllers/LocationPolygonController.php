<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LocationPolygonController extends Controller
{
    //
}
