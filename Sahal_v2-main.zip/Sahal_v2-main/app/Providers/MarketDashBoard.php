<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Models\User;
use App\Models\Order;
use App\Providers\Collection;
use App\Models\Product;

class MarketDashBoard extends ServiceProvider
{
    // for viewing specific dash board for a market 
    public static function dashBoard(User $market)
    {
         $marketOrders=Order::where('market_id',$market->id)->get(); // get all the orders from this market 
         $marketProducts=Product::where('market_id',$market->id)->get();
         $marketTakenOrders=$marketOrders->where('status','Done');

         // Get the number of the customers for specific market 
         $customerNum=$marketOrders->count();

         // Get the number of products for specific market 
         $productNum=$marketProducts->count();

         // Get the orders number for specific market 
         $orderNum=$marketTakenOrders->count();

         // Return the market's dashboard information 
        return response()->json([
            "number_of_customers" => $customerNum,
            "number_of_products" => $customerNum,
           "number_of_orders" => $orderNum
        ]);
        
    }//the end of the method 

}//the end of the class
